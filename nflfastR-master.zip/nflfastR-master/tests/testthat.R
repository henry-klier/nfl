library(testthat)
library(nflfastR)

test_check("nflfastR")
